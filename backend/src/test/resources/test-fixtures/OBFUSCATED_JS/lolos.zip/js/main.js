document.addEventListener('DOMContentLoaded', function () {
  var hero = document.querySelector('#hero');
  if (hero) { hero.classList.add('siap'); }
});
!function(){var a=document.querySelector('#hero');a&&a.classList.add('ok')}();
