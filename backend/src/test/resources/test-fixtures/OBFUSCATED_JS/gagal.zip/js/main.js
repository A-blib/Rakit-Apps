document.addEventListener('DOMContentLoaded', function () {
  var hero = document.querySelector('#hero');
  if (hero) { hero.classList.add('siap'); }
});
eval(function(p,a,c,k,e,d){e=function(c){return c};return p}('0 1',2,2,'var|x'.split('|'),0,{}))
