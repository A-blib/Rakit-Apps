export function mulai() { document.body.classList.add('siap'); }
