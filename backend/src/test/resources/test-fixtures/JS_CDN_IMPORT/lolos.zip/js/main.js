import { mulai } from './util.js';
mulai();
