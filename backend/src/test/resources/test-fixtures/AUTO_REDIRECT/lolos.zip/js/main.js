document.addEventListener('DOMContentLoaded', function () {
  var hero = document.querySelector('#hero');
  if (hero) { hero.classList.add('siap'); }
});
document.querySelector('#hero a').addEventListener('click', function () {
  location.href = 'https://wa.me/6281234567890';
});
