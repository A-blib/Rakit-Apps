document.addEventListener('DOMContentLoaded', function () {
  var hero = document.querySelector('#hero');
  if (hero) { hero.classList.add('siap'); }
});
var pola = /[{(]/g;
var nama = 'Bu Ani';
var teks = `Halo ${nama} {`;
var bagi = 10 / 2 / 1;
