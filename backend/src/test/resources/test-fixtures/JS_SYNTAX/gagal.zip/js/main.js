document.addEventListener('DOMContentLoaded', function () {
  var hero = document.querySelector('#hero');
  if (hero) { hero.classList.add('siap'); }
});
function rusak() {
  if (true) {
    console.log('x');
}
