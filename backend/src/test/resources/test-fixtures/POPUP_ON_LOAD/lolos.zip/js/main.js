document.addEventListener('DOMContentLoaded', function () {
  var hero = document.querySelector('#hero');
  if (hero) { hero.classList.add('siap'); }
});
function showAlert(pesan) { console.log(pesan); }
showAlert('ok');
