document.addEventListener('DOMContentLoaded', function () {
  var hero = document.querySelector('#hero');
  if (hero) { hero.classList.add('siap'); }
});
function evaluate(x) { return x * 2; }
evaluate(2);
