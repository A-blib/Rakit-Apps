// Script interaktif untuk template komunitas organisasi
document.addEventListener("DOMContentLoaded", function () {
  console.log("Template Organisasi Kreatif dimuat dengan sukses.");
});
